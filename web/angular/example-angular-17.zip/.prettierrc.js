module.exports = {
  printWidth: 80,
  semi: true,
  tabWidth: 2,
  trailingComma: "es5",
};
