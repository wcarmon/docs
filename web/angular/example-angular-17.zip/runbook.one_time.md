# Overview
1. One-time setup


# NodeJS LTS install

## Linux
1. `sudo snap remove --purge node`
1. `sudo snap install node --classic --channel=20`

## windows
1. TODO


# npm version bump
`sudo npm install -g npm@10.2.5`


# pnpm install
## Linux    
1. `sudo npm install -g pnpm`

## windows
1. TODO


# ng cli install
1. `npm install -g @angular/cli`
1. `ng config -g cli.packageManager pnpm`

## windows only
1. `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned`

# New project setup
1. `ng new my-poc-1`
1. `.npmrc`
    1. artifactory 


# ng cli update
1. `ng update @angular/core@17 @angular/cli@17`


# Angular Material
1. `ng add @angular/material`
    1. Automatically runs `pnpm install --save @angular/material @angular/cdk`


# verify
```bash
node -v;
pnpm -v;
npm -v;
npx -v;

ng version;
```


# Other resources
1. https://github.com/wcarmon/docs/blob/main/web/angular/setup.angular.md
1. https://github.com/wcarmon/docs/blob/main/web/angular/idioms.md
1. https://update.angular.io/
