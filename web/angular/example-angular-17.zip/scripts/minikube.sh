#!/bin/bash

# -----------------------------------------------------
# -- Runs ui-server via minikube
# --
# -- Assumptions:
# -- 1. minikube installed and already running via:
# --      minikube start;
# -- 2. kubectl installed (automatically inside minikube)
# -----------------------------------------------------
#set -x # uncomment to debug script
set -e # exit on first error
set -o pipefail
set -u # fail on unset var


# ---------------------------------------------
# -- Constants
# ---------------------------------------------
readonly PARENT_DIR=$(readlink -f "$(dirname "${BASH_SOURCE[0]}")/..")
readonly SCRIPT_DIR=$(readlink -f "$(dirname "${BASH_SOURCE[0]}")")
readonly KUBECTL="minikube kubectl --"


# ---------------------------------------------
# -- Script arguments
# ---------------------------------------------


# ---------------------------------------------
# -- Config
# ---------------------------------------------
readonly K8S_YAML_DIR="$PARENT_DIR/k8s"


# ---------------------------------------------
# -- Run
# ---------------------------------------------
#echo
#echo "|-- Starting minikube ..."
#minikube start;


echo
echo "|-- Enabling required minikube addons ..."
minikube addons enable ingress;
#minikube addons enable metrics-server


echo
echo "|-- Applying ui yamls ..."
$KUBECTL apply -f $K8S_YAML_DIR/

sleep 1;


# ---------------------------------------------
# -- Report
# ---------------------------------------------
echo
echo "|-- Deployment:"
$KUBECTL get deploy ui-deploy;

echo
echo "|-- Pods:"
$KUBECTL get pod --selector app=ui;


# ---------------------------------------------
# -- Debug
# ---------------------------------------------
<<'DEBUGGING'
echo
echo "|-- Deployment:"
$KUBECTL describe deploy ui-deploy

echo
echo "|-- Pod logs:"
$KUBECTL logs "`$KUBECTL get pods -l app=ui --output=jsonpath={.items..metadata.name}`";
#$KUBECTL logs --selector app=ui

echo
echo "|-- Events:"
$KUBECTL get events --namespace=default

echo
echo "|-- Entering pod:"
$KUBECTL exec -it deploy/ui-deploy -- /bin/ash;

DEBUGGING
