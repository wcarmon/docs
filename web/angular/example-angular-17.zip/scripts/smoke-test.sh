#!/bin/bash

# ---------------------------------------------
# -- Simulate the real deployment
# --
# -- Assumptions:
# -- 1. Docker installed: https://docs.docker.com/get-docker/
# -- 2. Minikube installed: https://minikube.sigs.k8s.io/docs/start/
# ---------------------------------------------

#set -x # uncomment to debug script
set -e # exit on first error
set -o pipefail
set -u # fail on unset var


# ------------------------------
# -- Config
# ------------------------------

# -- TODO: Align with image tag in ui.deploy.yaml
readonly VER="0.0.34"

#readonly CONTAINER_NAME="my_svr"


# ------------------------------
# -- Cleanup
# ------------------------------
#docker stop $CONTAINER_NAME || true
#docker rm $CONTAINER_NAME || true
#docker container prune --force
docker image prune --force

#minikube kubectl -- delete ing my-ingress || true;
#minikube kubectl -- delete deploy ui-deploy || true;

# -- Prune old images from minikube
# minikube cache delete todo-a:0.0.19


# ------------------------------
# -- Build
# ------------------------------
./scripts/build.image.sh $VER;
sleep 2

# ------------------------------
# -- Deploy to Docker
# ------------------------------
#echo ""
#echo "|-- Running docker container"
#docker run \
#--name $CONTAINER_NAME \
#-d \
#-p 13000:3000 \
#-p 13001:3001 \
#todo-a:latest


# ------------------------------
# -- Deploy to K8s
# ------------------------------
minikube kubectl -- apply -f $HOME/git-repos/web/poc-for-fund-credit/k8s


# ------------------------------
# -- Report
# ------------------------------

echo ""
echo "|-- Debug: Container Images"
echo "minikube image list"

echo ""
echo "|-- Debug: Logs"
echo "kubectl logs --selector app=ui"

echo ""
echo "|-- Debug: Enter the container"
echo "kubectl exec -it deploy/ui-deploy -- /bin/ash;"

# -- Run inside container
# cat /app/release/index.html
# cat /var/log/nginx/release.access.log
# ls -l /app/release

#echo
#echo "|-- Reach docker:"
#echo "http://localhost:13000/ui/"
#echo "http://localhost:13001/ui-debug/"  # success

echo
echo "|-- Reach Kubernetes:"
echo "http://$(minikube ip)/ui/"
echo "http://$(minikube ip)/ui-debug/"
