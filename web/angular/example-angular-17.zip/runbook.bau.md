# Overview
1. Routine usage guide


# Local dev
```bash
pnpm i;

npx barrelsby --config .barrelsby.config.json
npx prettier --loglevel log --write "src/**/*.{ts,tsx,js,jsx,json}"

ng serve --open;
# ng build --watch --configuration development;
```

# Pre-push
```bash
pnpm i
npx prettier --loglevel log --write "src/**/*.{ts,tsx,js,jsx,json}"
ng build

ng test

pnpm run eslint:check && pnpm run prettier:check

npx eslint --config .eslintrc.js

./scripts/build.image.sh 0.0.1
```


# Find & Bump old/outdated deps
1. `pnpm outdated`


# Debug an container image
```bash
docker run --rm -it node:20 /bin/bash
docker run --rm -it nginx:1.25-alpine /bin/ash
```
