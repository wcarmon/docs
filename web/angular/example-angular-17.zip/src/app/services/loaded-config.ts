/**
 * Kubernetes cluster deploy:
 * - See $PROJ_ROOT/k8s/ui.*.config.yaml
 * - kubectl describe cm ui-debug-config
 * - kubectl describe cm ui-release-config
 *
 * Local deploy (ng serve):
 * - See $PROJ_ROOT/src/assets/config/config.json
 */
export interface LoadedConf {

  env: "release" | "debug";
  title: string;

  // -- replace these with something useful
  a?: Array<number>
  b?: boolean
  i?: number
  zim?: object
}
