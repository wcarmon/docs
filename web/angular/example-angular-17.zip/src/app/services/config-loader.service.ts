import {Injectable} from '@angular/core';
import {LoadedConf} from "./loaded-config";
import autoBind from "auto-bind";

@Injectable({
  providedIn: 'root'
})
export class ConfigLoaderService {

  constructor() {
    autoBind(this);
  }

  async loadConfig(urls: string[]): Promise<LoadedConf> {

    let lastErr: any = null;

    // -- Return the first config that works
    for (const url of urls) {
      let loadedConf: LoadedConf;
      try {
        loadedConf = await this.loadConfigFromServer(url);

      } catch (e) {
        lastErr = e;
        continue;
      }

      this.validateStructure(loadedConf);

      console.info(`Successfully loaded and validated config from url=${url}`);
      return loadedConf;
    }

    throw lastErr;
  }

  private async loadConfigFromServer(url: string): Promise<LoadedConf> {

    if ((url || "").trim() === "") {
      throw new Error("url required");
    }

    const resp = await fetch(url);

    if (resp.status != 200) {
      console.debug(`Failed to load config from server: url=${url}`, resp);

      throw new Error(
        `Failed to load config from server: status=${resp.status}, statusText=${resp.statusText}`);
    }

    // TODO: fail better when config not loaded,
    // currently nginx try_files redirects missing config to index.html

    const confFromServer = await resp.json();
    if (!confFromServer) {
      throw new Error(`Failed to parse config from server (not valid json), url=${url}`);
    }

    return confFromServer;
  }

  private validateStructure(confFromServer: any) {
    console.warn("TODO: validate config structure here", confFromServer);

    if (!confFromServer.title || confFromServer.title.trim() === "") {
      throw new Error("config: title required");
    }
  }
}
