import { Component } from '@angular/core';

@Component({
  selector: 'app-screen2',
  standalone: true,
  imports: [],
  templateUrl: './screen2.component.html',
  styleUrl: './screen2.component.less'
})
export class Screen2Component {

}
