import { Component } from '@angular/core';

@Component({
  selector: 'app-screen1',
  standalone: true,
  imports: [],
  templateUrl: './screen1.component.html',
  styleUrl: './screen1.component.less'
})
export class Screen1Component {

}
