import {Component, OnInit} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import autoBind from "auto-bind";
import {ConfigLoaderService} from "./services/config-loader.service";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    RouterLinkActive,
    RouterOutlet,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.less',
})
export class AppComponent implements OnInit {

  private static readonly CONF_URLS = [
    // -- For kubernetes & docker
    "config/config.json",

    // -- For ng serve
    "assets/config/config.json",
  ]

  title = 'App';

  constructor(
    private configLoaderService: ConfigLoaderService) {

    autoBind(this);
  }

  async ngOnInit(): Promise<void> {
    const conf = await this.configLoaderService.loadConfig(AppComponent.CONF_URLS);

    console.info("conf:", conf);

    this.title = conf.title;
  }
}
